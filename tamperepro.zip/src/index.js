import sayHello from './hello';
import './index.scss';
import * as L from 'leaflet';

document.getElementById('root').innerHTML = sayHello();

let map = L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
	attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

let marker = L.marker([61.5,23.75]);
marker.addTo(map);

map.setView([61.4956, 23.7713], 11);


