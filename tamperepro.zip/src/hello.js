export default function sayHello() {
	return 'Hello World!';
}